# PM Brain — Setup Instructions

## What this does
Reads Jira tickets → sends to Claude → prints a ranked insight report
telling you exactly what to build next and why.

## Setup (3 steps)

### Step 1 — Install Python library
```
pip install anthropic
```

### Step 2 — Get your Anthropic API key
1. Go to console.anthropic.com
2. Sign up (free)
3. Click "API Keys" → Create Key
4. Copy the key

### Step 3 — Set your API key
On Mac/Linux:
```
export ANTHROPIC_API_KEY=sk-ant-your-key-here
```

On Windows:
```
set ANTHROPIC_API_KEY=sk-ant-your-key-here
```

## Run it
```
python brain.py
```

## Files
- mock_jira.json   — 25 realistic fake Jira tickets
- brain.py         — the complete brain script
- insights_output.json  — created after first run, raw JSON output
