"""
brain.py — Layer 2 PM Insight Engine
-------------------------------------
Reads Jira tickets (real or mock), sends to Claude,
gets back ranked product insights a PM can act on.

HOW TO RUN:
  1. pip install anthropic
  2. Set your API key: export ANTHROPIC_API_KEY=your_key_here
  3. python brain.py

"""

import json
import os
import anthropic

# ── 1. LOAD YOUR JIRA DATA ──────────────────────────────────────────
# Right now we use mock data. Later swap this for real Jira API calls.

def load_jira_data(filepath="mock_jira.json"):
    with open(filepath, "r") as f:
        data = json.load(f)
    print(f"Loaded {data['total_issues']} issues from project: {data['project']}\n")
    return data


# ── 2. THE BRAIN SYSTEM PROMPT ──────────────────────────────────────
# This is your secret sauce. These instructions tell Claude how to
# think like a senior PM. This is YOUR intellectual property.

SYSTEM_PROMPT = """
You are a senior product strategist with 10 years of experience at 
high-growth B2B SaaS companies. You think deeply, reason from evidence, 
and give direct, confident recommendations.

You will be given a list of Jira issues from a software product team.
Your job is to analyze them and answer the question every PM dreads:
"What should we actually build next — and why?"

YOUR ANALYSIS MUST DO ALL OF THE FOLLOWING:

1. FIND HIDDEN THEMES
   - Group tickets by the REAL underlying problem, not surface labels
   - Look for tickets that seem different but share a root cause
   - Count how many tickets belong to each theme
   - Note how long the oldest ticket in each theme has sat in backlog

2. FIND WHAT THE TEAM IS AVOIDING
   - Identify high-priority tickets that keep getting deprioritized
   - Look for patterns in which problems never get solved
   - This reveals organizational blind spots or engineering fear

3. FIND REVENUE-BLOCKING ISSUES
   - Look for comments mentioning: deals blocked, enterprise, churn,
     customer complaints, sales, QBR, procurement
   - These are your highest-leverage items

4. MAKE A CLEAR RECOMMENDATION
   - Pick ONE thing to build next
   - Justify it with specific evidence from ticket comments
   - Give a rough scope (what a v1 looks like)
   - Explain the risk of NOT building it

5. FLAG QUICK WINS
   - Identify 1-2 bugs or small fixes that unblock the most users
   - These can be done in parallel with the main recommendation

RETURN VALID JSON ONLY. No explanation before or after. No markdown.
Use exactly this structure:

{
  "summary": "2-3 sentence executive summary of what you found",
  "themes": [
    {
      "name": "Theme name",
      "ticket_count": 3,
      "oldest_days_in_backlog": 67,
      "signal_strength": "high|medium|low",
      "description": "What the real problem is",
      "evidence": ["quote from comment 1", "quote from comment 2"]
    }
  ],
  "avoided_problems": [
    {
      "issue_id": "TF-XXX",
      "title": "ticket title",
      "days_avoided": 91,
      "why_it_matters": "explanation"
    }
  ],
  "recommendation": {
    "what": "Feature name",
    "why": "Detailed reasoning tied to evidence",
    "v1_scope": "What a minimum first version looks like",
    "risk_of_not_building": "What happens if you skip this",
    "supporting_tickets": ["TF-001", "TF-002"]
  },
  "quick_wins": [
    {
      "issue_id": "TF-XXX",
      "title": "ticket title",
      "why_now": "why this is fast and high impact"
    }
  ]
}
"""


# ── 3. CALL CLAUDE — THE BRAIN ACTUALLY RUNS ────────────────────────

def run_brain(jira_data):
    # Initialize the Claude client
    # It automatically reads ANTHROPIC_API_KEY from your environment
    client = anthropic.Anthropic()

    # Format the Jira data into a clean message for Claude
    user_message = f"""
Here are {jira_data['total_issues']} Jira issues from project {jira_data['project']}.
Analyze them and tell me what to build next.

ISSUES:
{json.dumps(jira_data['issues'], indent=2)}

What should this team build next and why?
"""

    print("Sending to Claude brain... thinking...\n")

    # Call the Claude API
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        system=SYSTEM_PROMPT,
        messages=[
            {"role": "user", "content": user_message}
        ]
    )

    # Extract the text response
    raw_output = response.content[0].text

    # Parse the JSON Claude returns
    insights = json.loads(raw_output)
    return insights


# ── 4. DISPLAY THE INSIGHT REPORT ───────────────────────────────────
# Turn the JSON into a clean, readable PM report in the terminal

def display_report(insights):
    print("=" * 60)
    print("  PRODUCT INSIGHT REPORT")
    print("=" * 60)

    # Executive summary
    print(f"\nSUMMARY\n{insights['summary']}\n")

    # Themes found
    print("-" * 60)
    print("THEMES FOUND IN YOUR BACKLOG\n")
    for i, theme in enumerate(insights['themes'], 1):
        signal_icon = {"high": "!!!", "medium": "!!", "low": "!"}.get(theme['signal_strength'], "!")
        print(f"{i}. {theme['name']}  [{signal_icon} {theme['signal_strength'].upper()} SIGNAL]")
        print(f"   Tickets: {theme['ticket_count']}  |  Oldest: {theme['oldest_days_in_backlog']} days in backlog")
        print(f"   Problem: {theme['description']}")
        if theme.get('evidence'):
            print(f"   Evidence: \"{theme['evidence'][0]}\"")
        print()

    # What the team is avoiding
    if insights.get('avoided_problems'):
        print("-" * 60)
        print("WHAT YOUR TEAM IS SILENTLY AVOIDING\n")
        for item in insights['avoided_problems']:
            print(f"  {item['issue_id']}: {item['title']}")
            print(f"  Avoided for {item['days_avoided']} days — {item['why_it_matters']}\n")

    # The main recommendation
    print("-" * 60)
    rec = insights['recommendation']
    print(f"RECOMMENDATION: BUILD '{rec['what'].upper()}' NEXT\n")
    print(f"Why: {rec['why']}\n")
    print(f"V1 Scope: {rec['v1_scope']}\n")
    print(f"Risk of skipping: {rec['risk_of_not_building']}\n")
    print(f"Tickets: {', '.join(rec['supporting_tickets'])}")

    # Quick wins
    if insights.get('quick_wins'):
        print("\n" + "-" * 60)
        print("QUICK WINS — DO THESE IN PARALLEL\n")
        for win in insights['quick_wins']:
            print(f"  {win['issue_id']}: {win['title']}")
            print(f"  Why now: {win['why_now']}\n")

    print("=" * 60)
    print("Report complete.")

    # Also save the raw JSON for later use
    with open("insights_output.json", "w") as f:
        json.dump(insights, f, indent=2)
    print("Raw JSON saved to insights_output.json")


# ── 5. RUN EVERYTHING ───────────────────────────────────────────────

if __name__ == "__main__":
    # Check API key exists
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: No API key found.")
        print("Run this first: export ANTHROPIC_API_KEY=your_key_here")
        exit(1)

    # Load Jira data
    jira_data = load_jira_data("mock_jira.json")

    # Run the brain
    insights = run_brain(jira_data)

    # Display the report
    display_report(insights)
